const functions = require("firebase-functions");
const badwords = ["fuck", "shit"];
// Moderates messages by lowering all uppercase messages and removing swearword
exports.moderator = functions.firestore.document("/comments/{commentId}")
    .onWrite((change) => {
      functions.logger.log("Main function ran, updated 11:36");
      const comment = change.after.data();
      const message = comment.commentContent;
      functions.logger.log(message);
      if (message) {
        // Retrieved the message values.
        // functions.logger.log('Retrieved message content: ', message);
        // Run moderation checks on on the message and moderate if needed.
        const moderatedMessage = moderateMessage(message);
        // Update the Firebase DB with checked message.
        functions.logger.log(
            // 'Message has been moderated. Saving to DB: ',
            moderatedMessage
        );
        return change.after.ref.update({
          commentContent: moderatedMessage,
        });
      }
      return null;
    });

/**
 * moderateMessage
 * @param {string} message Message
 * @return {string} The edited message.
 */
function moderateMessage(message) {
  if (containsSwearwords(message)) {
    functions.logger.log("contains swear words");
    message = moderateSwearwords(message);
  }
  return message;
}

/**
 * ContainsSwearwords
 * @param {string} message Message
 * @return {boolean} Whether message contains swear words
 */
function containsSwearwords(message) {
  let i;
  for (i = 0; i < badwords.length; i++) {
    if (message.includes(badwords[i])) {
      return true;
    }
  }
  return false;
}

/**
 * Moderates swear words
 * @param {string} message Message
 * @return {string} The edited message.
 */
function moderateSwearwords(message) {
  functions.logger.log("moderating swear words");
  let i;
  for (i = 0; i < badwords.length; i++) {
    if (message.includes(badwords[i])) {
      while (message.includes(badwords[i])) {
        message = message.replace(badwords[i], "*".repeat(badwords[i].length));
      }
    }
  }
  return message;
}

